package com.example.mycity.ui

import androidx.lifecycle.ViewModel
import com.example.mycity.data.DataSource
import com.example.mycity.model.Category
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class MyCityViewModel: ViewModel() {
    private val _uiState = MutableStateFlow(
        MyCityUiState(
            categories = DataSource.categories,
        )
    )
    val uiState: StateFlow<MyCityUiState> = _uiState

    fun updateCurrentCategory(selectedCategory: Category?) {
        _uiState.update {
            it.copy(curCategory = selectedCategory)
        }
    }

    fun navigateToCategories() {
        _uiState.update {
            it.copy(isShowingCategories = true)
        }
    }

    fun navigateToPlaces() {
        _uiState.update {
            it.copy(isShowingCategories = false)
        }
    }
}

data class MyCityUiState(
    val categories: List<Category> = DataSource.categories,
    val curCategory: Category? = DataSource.categories[0],
    val isShowingCategories : Boolean = true
)