package com.example.mycity.data

import com.example.mycity.R
import com.example.mycity.model.Category
import com.example.mycity.model.Place

object DataSource {
    val restaurants = Category (
        name = R.string.restaurant_category,
        image = R.drawable.restaurant_category,
        listOf(
            Place (
                name = R.string.restaurant_1,
                description = R.string.description,
                photo = R.drawable.restaurant_1
            ),
            Place (
                name = R.string.restaurant_2,
                description = R.string.description,
                photo = R.drawable.restaurant_2
            ),
            Place (
                name = R.string.restaurant_3,
                description = R.string.description,
                photo = R.drawable.restaurant3
            )
        )
    )
    private val cinemas = Category(
        name = R.string.cinema_category,
        image = R.drawable.cinema_category,
        places = listOf(
            Place (
                name = R.string.restaurant_1,
                description = R.string.description,
                photo = R.drawable.cinema_1
            ),
            Place (
                name = R.string.restaurant_2,
                description = R.string.description,
                photo = R.drawable.cinema_2
            ),
            Place (
                name = R.string.restaurant_3,
                description = R.string.description,
                photo = R.drawable.cinema_3
            )
        )
    )
    private val shoppingCentres = Category(
        name = R.string.shopping_centre_category,
        image = R.drawable.shopping_centres_category,
        places = listOf(
            Place (
                name = R.string.restaurant_1,
                description = R.string.description,
                photo = R.drawable.shopping_centre_1
            ),
            Place (
                name = R.string.restaurant_2,
                description = R.string.description,
                photo = R.drawable.shopping_centre_2
            ),
            Place (
                name = R.string.restaurant_3,
                description = R.string.description,
                photo = R.drawable.shopping_centre_3
            ),
            Place (
                name = R.string.restaurant_2,
                description = R.string.description,
                photo = R.drawable.shopping_centre_4
            ),
            Place (
                name = R.string.restaurant_1,
                description = R.string.description,
                photo = R.drawable.shopping_centre_5
            )
        )
    )
    val categories = listOf(cinemas, restaurants, shoppingCentres)
}