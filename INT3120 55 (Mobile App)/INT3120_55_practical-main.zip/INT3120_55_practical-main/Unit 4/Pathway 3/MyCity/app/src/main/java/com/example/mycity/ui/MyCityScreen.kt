package com.example.mycity.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.mycity.R
import com.example.mycity.data.DataSource
import com.example.mycity.model.Category
import com.example.mycity.model.Place
import com.example.mycity.ui.theme.MyCityTheme

@ExperimentalMaterial3Api
@Composable
fun MyCityApp(width: Dp, onBackPressed: () -> Unit) {
    val viewModel: MyCityViewModel = viewModel()
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            MyCityAppBar(
                width = width,
                isShowingCategories = uiState.isShowingCategories,
                onBackButtonClick = { viewModel.navigateToCategories() }
            )
        }
    ) { innerPadding ->
        if (isLargeScreen(width)) {
            CategoriesAndPlaces(
                categories = uiState.categories,
                selectedCategory = uiState.curCategory,
                onClick = {
                    viewModel.updateCurrentCategory(it)
                },
                onBackPressed = onBackPressed,
                contentPadding = innerPadding,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            if (uiState.isShowingCategories) {
                CategoriesList(
                    categories = uiState.categories,
                    onClick = {
                        viewModel.updateCurrentCategory(it)
                        viewModel.navigateToPlaces()
                    },
                    modifier = Modifier.padding(horizontal = 16.dp),
                    contentPadding = innerPadding,
                )
            } else {
                PlacesList(
                    selectedCategory = uiState.curCategory,
                    contentPadding = innerPadding,
                    onBackPressed = {
                        viewModel.navigateToCategories()
                    }
                )
            }
        }
    }
}

@ExperimentalMaterial3Api
@Composable
fun MyCityAppBar(
    width: Dp,
    isShowingCategories: Boolean,
    onBackButtonClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val isShowingPlaces = !isLargeScreen(width) && !isShowingCategories
    TopAppBar (
        title = {
            Text(
                if (isShowingPlaces) {
                    stringResource(R.string.recommendations)
                } else {
                    stringResource(R.string.app_name)
                }
            )
        },
        navigationIcon = if (isShowingPlaces) {
            {
                IconButton(onClick = onBackButtonClick) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = null
                    )
                }
            }
        } else {
            { Box {} }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.primary
        ),
        modifier = modifier,
    )
}

@Composable
fun CategoriesAndPlaces(
    categories: List<Category> = emptyList(),
    selectedCategory: Category? = null,
    onClick: (Category) -> Unit,
    onBackPressed: () -> Unit,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    modifier: Modifier = Modifier
) {
    Row (
        modifier =  modifier.fillMaxSize()
    ) {
        CategoriesList(
            categories = categories,
            onClick = onClick,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp),
            contentPadding = contentPadding
        )
        PlacesList(
            selectedCategory = selectedCategory,
            modifier = Modifier
                .weight(2f)
                .padding(horizontal = 8.dp),
            onBackPressed = onBackPressed,
            contentPadding = contentPadding
        )
    }
}

@Composable
fun CategoriesList(
    categories: List<Category>,
    onClick: (Category) -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(0.dp),
) {
    LazyColumn(
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        itemsIndexed(categories) {
            index, category -> CategoryItem(
            category = category,
            onItemClick = onClick)
        }
    }
}

@Composable
fun CategoryItem (
    category: Category,
    modifier: Modifier = Modifier,
    onItemClick: (Category) -> Unit
) {
    Card (
        modifier = modifier.padding(8.dp),
        onClick = {onItemClick(category)}
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(70.dp)) {
            Image(
                painter = painterResource(category.image),
                contentDescription = stringResource(category.name),
                modifier = Modifier.height(70.dp).width(70.dp),
                contentScale = ContentScale.Crop
            )
            Column {
                Text(
                    text = stringResource(category.name),
                    modifier = Modifier.padding(
                        top = 16.dp,
                        start = 16.dp,
                        end = 16.dp,
                        bottom = 8.dp
                    )
                )
            }
        }
    }
}

@Composable
fun PlacesList(
    selectedCategory: Category?,
    modifier : Modifier = Modifier,
    onBackPressed : () -> Unit,
    contentPadding: PaddingValues = PaddingValues(0.dp),
) {
    LazyColumn(
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier,
    ) {
        if (selectedCategory != null) {
            itemsIndexed(selectedCategory.places) {
                    index, place -> PlaceItem(
                place = place,
                onBackPressed = onBackPressed
            )
            }
        }
    }
}

@Composable
fun PlaceItem(
    place: Place,
    onBackPressed: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBackPressed()
    }
    var expanded by remember { mutableStateOf(false) }
    Card(
        modifier = modifier.padding(8.dp)
    ) {
        Column(
            modifier = Modifier
                .animateContentSize(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessMedium
                    )
                )
        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                Image(
                    painter = painterResource(place.photo),
                    contentDescription = null,
                    modifier = Modifier.height(70.dp).width(70.dp),
                    contentScale = ContentScale.Crop
                )
                Column {
                    Text(
                        text = stringResource(place.name),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(
                            top = 16.dp,
                            start = 16.dp,
                            end = 16.dp,
                            bottom = 8.dp
                        )
                    )
                }
                Spacer(Modifier.weight(1f))
                IconButton(
                    onClick = {expanded = !expanded}
                ) {
                    Icon(
                        imageVector = if (expanded) {
                            Icons.Filled.KeyboardArrowUp
                        } else{
                            Icons.Filled.KeyboardArrowDown
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            if (expanded) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = stringResource(place.description),
                    )
                }
            }
        }
    }
}

private fun isLargeScreen(width: Dp) : Boolean {
    return width >= 840.dp
}

//@Preview
//@Composable
//fun CategoriesListPreview() {
//    MyCityTheme {
//        Surface {
//            CategoriesList(
//                categories = DataSource.categories,
//                onClick = {}
//            )
//        }
//    }
//}

//@Preview
//@Composable
//fun PlacesListPreview() {
//    MyCityTheme {
//        Surface {
//            PlacesList(
//                selectedCategory = DataSource.restaurants,
//                onBackPressed = {}
//            )
//        }
//    }
//}

@Preview
@Composable
fun CategoriesAndPlaces() {
    MyCityTheme {
        Surface {
            CategoriesAndPlaces(
                categories = DataSource.categories,
                selectedCategory = DataSource.restaurants,
                onClick = {},
                onBackPressed = {}
            )
        }
    }
}