package com.example.dessertclicker.ui.theme

import androidx.lifecycle.ViewModel
import com.example.dessertclicker.data.Datasource.dessertList
import com.example.dessertclicker.data.DessertUIState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class DessertViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(DessertUIState())
    val uiState: StateFlow<DessertUIState> = _uiState.asStateFlow()

    fun onDessertButtonClicked() {
        _uiState.update { cupcakeUIState ->
            val dessertsSold = cupcakeUIState.dessertsSold + 1
            val nextDessertId = findNextDessert(dessertsSold)
            cupcakeUIState.copy(
                curDessert = nextDessertId,
                dessertsSold = dessertsSold,
                revenue = cupcakeUIState.revenue + cupcakeUIState.curPrice,
                curPrice = dessertList[nextDessertId].price,
                curDessertImageId = dessertList[nextDessertId].imageId
            )
        }
    }

    private fun findNextDessert(dessertsSold : Int) : Int {
        var dessertId = 0
        for (id in dessertList.indices) {
            if (dessertsSold >= dessertList[id].startProductionAmount) {
                dessertId = id
            } else {
                break
            }
        }
        return dessertId
    }
}
