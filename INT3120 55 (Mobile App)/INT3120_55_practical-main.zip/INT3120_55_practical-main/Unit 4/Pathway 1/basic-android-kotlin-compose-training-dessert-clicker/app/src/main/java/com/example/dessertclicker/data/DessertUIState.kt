package com.example.dessertclicker.data

import androidx.annotation.DrawableRes
import com.example.dessertclicker.data.Datasource.dessertList

data class DessertUIState(
    val curDessert: Int = 0,
    val dessertsSold: Int = 0,
    val revenue: Int = 0,
    val curPrice: Int = dessertList[curDessert].price,
    @DrawableRes val curDessertImageId: Int = dessertList[curDessert].imageId
)
