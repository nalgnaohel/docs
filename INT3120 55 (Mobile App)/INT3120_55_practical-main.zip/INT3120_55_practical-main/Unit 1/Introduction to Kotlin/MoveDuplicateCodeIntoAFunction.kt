fun main() {
    printCityDetails("Ankara", 27, 31, 82)
    printCityDetails("Tokyo", 32, 36, 10)
    printCityDetails("Cape Town", 59, 64, 2)
    printCityDetails("Guatemala City", 50, 55, 7)
}

fun printCityDetails(city: String, lowTemp: Int, highTemp: Int, chanceOfRain: Int) {
    println("City: $city")
    println("Low temperature: $lowTemp, High temperature: $highTemp")
    println("Chance of rain: $chanceOfRain%\n")
}