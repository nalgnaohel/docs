//Lỗi là do hai biến discountPerceentage và offer được khai báo val => không thay đổi được giá trị.
//Sửa như code bên dưới.
fun main() {
    var discountPercentage: Int = 0
    var offer: String = ""
    val item = "Google Chromecast"
    discountPercentage = 20
    offer = "Sale - Up to $discountPercentage% discount on $item! Hurry up!"

    println(offer)
}