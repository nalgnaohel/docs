/**
 * You can edit, run, and share this code.
 * play.kotlinlang.org
 */
fun main() {
    val firstNumber = 10
    val secondNumber = 5
    val thirdNumber = 8

    var result = add(firstNumber, secondNumber)
    var anotherResult = add(firstNumber, thirdNumber)

    println("$firstNumber + $secondNumber = $result")
    println("$firstNumber + $thirdNumber = $anotherResult")

    result = subtract(firstNumber, secondNumber)
    anotherResult = subtract(firstNumber, thirdNumber)
    println("$firstNumber - $secondNumber = $result")
    println("$firstNumber - $thirdNumber = $anotherResult")
}

// Define add() function below this line
fun add(firstNumber : Int, secondNumber : Int) : Int {
    val result = firstNumber + secondNumber
    return result
}

fun subtract(firstNumber : Int, secondNumber : Int) : Int {
    val result = firstNumber - secondNumber
    return result
}