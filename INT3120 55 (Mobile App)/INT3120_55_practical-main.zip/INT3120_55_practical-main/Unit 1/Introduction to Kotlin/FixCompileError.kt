//Lỗi là do cuối lệnh in thiếu dấu ')', kết String trong lệnh in thiếu dấu đóng ".
fun main() {
    println("New chat message from a friend")
}