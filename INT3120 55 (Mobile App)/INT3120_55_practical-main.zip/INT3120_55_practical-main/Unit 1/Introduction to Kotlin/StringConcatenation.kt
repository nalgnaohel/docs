//Lỗi do hai biến đều khai báo trong ngoặc kép => ctrinh ngầm hiểu chúng là String => thực hiện phép cộng String.
//Sửa như dưới.
fun main() {
    val numberOfAdults = 20
    val numberOfKids = 30
    val total = numberOfAdults + numberOfKids
    println("The total party size is: $total")
}