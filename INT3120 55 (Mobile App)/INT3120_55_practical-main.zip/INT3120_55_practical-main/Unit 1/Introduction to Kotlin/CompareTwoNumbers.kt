fun main() {
    println(compareMins(200, 250))
}

fun compareMins(timeSpentToday: Int, timeSpentYesterday: Int): Boolean {
    if (timeSpentToday > timeSpentYesterday) {
        return true
    }
    return false
}