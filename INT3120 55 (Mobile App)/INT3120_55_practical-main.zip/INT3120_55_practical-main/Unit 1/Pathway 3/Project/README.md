Here is the preview of this unit's project

![Image Description](https://github.com/nalgnaohel/INT3120_55_practical/blob/main/Unit%201/Pathway%203/Project/CardScreenshot.png)

