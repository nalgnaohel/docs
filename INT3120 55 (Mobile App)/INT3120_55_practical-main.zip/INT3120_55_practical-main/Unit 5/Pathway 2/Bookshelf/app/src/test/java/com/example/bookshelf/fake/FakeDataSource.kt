package com.example.bookshelf.fake

import com.example.bookshelf.model.Book
import com.example.bookshelf.model.ImageLinks
import com.example.bookshelf.model.VolumeInfo

object FakeDataSource {
    val books = listOf(
        Book(
            id = "a",
            description = "b",
            volumeInfo = VolumeInfo(
                title = "F1",
                subtitle = "sub F1",
                description = "?",
                imageLinks = ImageLinks("url.1"),
                authors = listOf("A", "B")
            )
        ),
        Book(
            id = "b",
            description = "c",
            volumeInfo = VolumeInfo(
                title = "F2",
                subtitle = "sub F2",
                description = "??",
                imageLinks = ImageLinks("url.2"),
                authors = listOf("B", "C")
            )
        ),
    )
}