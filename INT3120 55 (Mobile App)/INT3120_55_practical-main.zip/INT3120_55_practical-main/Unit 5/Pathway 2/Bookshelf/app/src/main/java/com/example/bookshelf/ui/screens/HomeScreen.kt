package com.example.bookshelf.ui.screens

import android.view.KeyEvent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.bookshelf.R

@Composable
fun HomeScreen(
    viewModel:  BookshelfViewModel,
    retryAction: () -> Unit,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(0.dp)
) {
    val queryUiState = viewModel.queryUiState.collectAsState().value
    val searchUiState = viewModel.searchUiState.collectAsState().value

    val focusManager = LocalFocusManager.current
    Column (Modifier.fillMaxSize().padding(contentPadding)) {
        OutlinedTextField(
            value = searchUiState.query,
            onValueChange = { viewModel.updateQuery(it) },
            singleLine = true,
            placeholder = {
                Text(text = stringResource(R.string.searchbar_placeholder))
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Search
            ),
            keyboardActions = KeyboardActions(
                onSearch = {
                    focusManager.clearFocus()
                    viewModel.getBooks(searchUiState.query)
                }
            ),
            modifier = Modifier
                .onKeyEvent { event ->
                    if (event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_ENTER) {
                        focusManager.clearFocus()
                        viewModel.getBooks(searchUiState.query)
                    }
                    false
                }
                .fillMaxWidth()
                .padding(start = 10.dp, end = 10.dp, top = 10.dp)
        )

        if (searchUiState.searchEnabled) {
            when (queryUiState) {
                is QueryUiState.Loading -> LoadingScreen(modifier)
                is QueryUiState.Success -> BooksGrid(
                    books = queryUiState.books,
                    modifier = modifier
                )
                else ->
                    ErrorScreen(retryAction = retryAction, modifier = modifier)
            }
        }
    }
}