package com.example.bookshelf.fake

import com.example.bookshelf.model.QueryResponse
import com.example.bookshelf.network.BookshelfApiService
import retrofit2.Response

class FakeBookshelfApiService: BookshelfApiService {
    override suspend fun getBooks(query: String): Response<QueryResponse> {
        return Response.success(QueryResponse(FakeDataSource.books, totalItems = 2, kind = "fake"))
    }
}