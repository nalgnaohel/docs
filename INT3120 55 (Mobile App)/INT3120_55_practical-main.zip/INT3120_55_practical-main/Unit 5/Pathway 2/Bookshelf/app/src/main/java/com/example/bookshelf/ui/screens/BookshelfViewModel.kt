package com.example.bookshelf.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.bookshelf.BookshelfApplication
import com.example.bookshelf.data.BookshelfRepository
import com.example.bookshelf.model.Book
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

sealed interface QueryUiState {
    data class Success(val books: List<Book>) : QueryUiState
    object Error : QueryUiState
    object Loading : QueryUiState
}

data class SearchUiState (
    val query : String = "",
    val searchEnabled: Boolean = false
)

class BookshelfViewModel (private val bookshelfRepository: BookshelfRepository) : ViewModel() {
    private val _queryUiState = MutableStateFlow<QueryUiState>(QueryUiState.Loading)
    val queryUiState = _queryUiState.asStateFlow()

    var selectedBookId by mutableStateOf("")

    private val _searchUiState = MutableStateFlow(SearchUiState())
    val searchUiState = _searchUiState.asStateFlow()

    fun updateQuery(query: String){
        _searchUiState.update { currentState ->
            currentState.copy(
                query = query
            )
        }
    }

    fun updateSearchEnabled(searchEnabled: Boolean){
        _searchUiState.update { currentState ->
            currentState.copy(
                searchEnabled = searchEnabled
            )
        }
    }
    fun getBooks(query: String = "") {
        updateSearchEnabled(true)
        viewModelScope.launch {
            _queryUiState.value = QueryUiState.Loading

            _queryUiState.value = try {
                val books = bookshelfRepository.getBooks(query)
                if (books == null) {
                    QueryUiState.Error
                } else if (books.isEmpty()){
                    QueryUiState.Success(emptyList())
                } else{
                    QueryUiState.Success(books)
                }
            } catch (e: IOException) {
                QueryUiState.Error
            } catch (e: HttpException) {
                QueryUiState.Error
            }
        }
    }


    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application =
                    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BookshelfApplication)
                val bookshelfRepository = application.container.bookshelfRepository
                BookshelfViewModel(bookshelfRepository = bookshelfRepository)
            }
        }
    }
}