package com.example.bookshelf.fake

import com.example.bookshelf.data.BookshelfRepository
import com.example.bookshelf.data.DefaultBookshelfRepository
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

class BookshelfRepositoryTest {
    @Test
    fun defaultbookshelfRepository_getBooks_verifyBooks(){
        runTest {
            val repository = DefaultBookshelfRepository(
                bookshelfApiService = FakeBookshelfApiService()
            )
            assertEquals(FakeDataSource.books, repository.getBooks(""))
        }
    }
}