---
name: Get Data from the Internet issue template
about: Issue template for Get Data From the Internet codelab
title: Get Data from the Internet
labels: ''
assignees: ''

---

**URL of codelab:**


**Specify the language of the codelab if it is not English:**



**In which task and step of the codelab can this issue be found?**


**Describe the problem**




**Steps to reproduce?**
1. Go to...
2. Click on...
3. See error...

**Versions**
_Android Studio version:_
_API version of the emulator:_


**Additional information**
_Include screenshots if they would be useful in clarifying the problem._
