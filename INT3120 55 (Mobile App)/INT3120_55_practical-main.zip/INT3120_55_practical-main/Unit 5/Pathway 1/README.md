Notes: Mars Photo is available at Pathway 2
