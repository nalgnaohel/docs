package com.example.a30_day.data

import com.example.a30_day.R
import com.example.a30_day.model.Day

object DataSource {
    val days = listOf(
        Day(R.string.architecture, R.drawable.architecture),
        Day(R.string.automotive, R.drawable.automotive),
        Day(R.string.biology, R.drawable.biology),
        Day(R.string.crafts, R.drawable.crafts),
        Day(R.string.business, R.drawable.business),
        Day(R.string.rest, R.drawable.rest),
        Day(R.string.culinary, R.drawable.culinary),
        Day(R.string.design,  R.drawable.design),
        Day(R.string.ecology, R.drawable.ecology),
        Day(R.string.rest, R.drawable.rest),
        Day(R.string.engineering, R.drawable.engineering),
        Day(R.string.rest, R.drawable.rest),
        Day(R.string.fashion, R.drawable.fashion),
        Day(R.string.finance, R.drawable.finance),
        Day(R.string.film, R.drawable.film),
        Day(R.string.gaming, R.drawable.gaming),
        Day(R.string.geology, R.drawable.geology),
        Day(R.string.rest, R.drawable.rest),
        Day(R.string.drawing,  R.drawable.drawing),
        Day(R.string.history,  R.drawable.history),
        Day(R.string.journalism, R.drawable.journalism),
        Day(R.string.law,  R.drawable.law),
        Day(R.string.lifestyle, R.drawable.lifestyle),
        Day(R.string.rest, R.drawable.rest),
        Day(R.string.music, R.drawable.music),
        Day(R.string.painting,  R.drawable.painting),
        Day(R.string.photography,  R.drawable.photography),
        Day(R.string.physics,  R.drawable.physics),
        Day(R.string.tech,  R.drawable.tech),
        Day(R.string.rest, R.drawable.rest)
    )
}