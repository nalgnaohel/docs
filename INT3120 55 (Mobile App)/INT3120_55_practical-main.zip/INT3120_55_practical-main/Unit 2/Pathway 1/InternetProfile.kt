fun main() {
    val amanda = Person("Amanda", 33, "play tennis", null)
    val atiqah = Person("Atiqah", 28, "climb", amanda)

    amanda.showProfile()
    atiqah.showProfile()
}

class Person(val name: String, val age: Int, val hobby: String?, val referrer: Person?) {
    fun showProfile() {
        // Fill in code
        println("Name: $name")
        println("Age: $age")
        var res : String =  ""
        if (hobby != null) {
            res += "Likes to $hobby. "
        }
        if (referrer == null) {
            res += "Doesn't have a referrer.\n"
        } else {
            res += "Has a referrer named ${referrer.name}"
            if (referrer.hobby != null) {
                res += ", who likes to ${referrer.hobby}\n"
            } else {
                res += ".\n"
            }
        }
        println(res)
    }
}