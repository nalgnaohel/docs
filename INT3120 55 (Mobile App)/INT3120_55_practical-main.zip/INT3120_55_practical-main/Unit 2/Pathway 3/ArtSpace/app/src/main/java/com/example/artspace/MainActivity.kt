package com.example.artspace

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.artspace.ui.theme.ArtSpaceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ArtSpaceTheme {
                ArtSpaceApp()
            }
        }
    }
}

@Composable
fun ArtSpaceApp() {
    val firstArtwork = R.drawable.kirari_smile
    val secondArtwork = R.drawable.yumeko
    val thirdArtwork = R.drawable.kirari_excited
    val forthArtwork = R.drawable.love_yerin
    var curArtwork by remember {
        mutableStateOf(firstArtwork)
    }
    var curTitle by remember {
        mutableStateOf(R.string.first_title)
    }
    var curAuthor by remember {
        mutableStateOf(R.string.first_author)
    }
    Scaffold() {
        innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            Column (
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ArtSpaceArtwork(
                    artworkPainter = painterResource(curArtwork),
                    artworkTitle = stringResource(curTitle),
                    artworkArtist = stringResource(curAuthor)
                )
                Spacer(Modifier.height(20. dp))

                Row (
                    modifier = Modifier.padding(horizontal = 10.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        onClick = {
                            when (curArtwork) {
                                firstArtwork -> {
                                    curArtwork = forthArtwork
                                    curTitle = R.string.forth_title
                                    curAuthor = R.string.forth_author
                                }
                                secondArtwork -> {
                                    curArtwork = firstArtwork
                                    curTitle = R.string.first_title
                                    curAuthor = R.string.first_author
                                }
                                thirdArtwork -> {
                                    curArtwork = secondArtwork
                                    curTitle = R.string.second_title
                                    curAuthor = R.string.second_author
                                }
                                else -> {
                                    curArtwork = thirdArtwork
                                    curTitle = R.string.third_title
                                    curAuthor = R.string.third_author
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(246, 142, 194)
                        )
                    ) {
                        Text(
                            text = "Previous",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                    Spacer (Modifier.width(10.dp))
                    Button(
                        onClick = {
                            when (curArtwork) {
                                firstArtwork -> {
                                    curArtwork = secondArtwork
                                    curTitle = R.string.second_title
                                    curAuthor = R.string.second_author
                                }
                                secondArtwork -> {
                                    curArtwork = thirdArtwork
                                    curTitle = R.string.third_title
                                    curAuthor = R.string.third_author
                                }
                                thirdArtwork -> {
                                    curArtwork = forthArtwork
                                    curTitle = R.string.forth_title
                                    curAuthor = R.string.forth_author
                                }
                                else -> {
                                    curArtwork = firstArtwork
                                    curTitle = R.string.first_title
                                    curAuthor = R.string.first_author
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(246, 142, 194)
                        )
                    ) {
                        Text(
                            text = "Next",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ArtSpaceArtwork(
    artworkPainter : Painter,
    artworkTitle : String,
    artworkArtist : String
) {
    Column (
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image (painter = artworkPainter, contentDescription = artworkTitle)
        Spacer (Modifier.height(16. dp))
        Column (
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text (
                text = artworkTitle,
                fontSize = 32. sp,
                fontWeight = FontWeight.Bold
            )
            Text (
                text = artworkArtist,
                fontSize = 16. sp
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ArtSpacePreview() {
    ArtSpaceTheme {
        ArtSpaceApp()
    }
}